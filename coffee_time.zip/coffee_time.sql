-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jun 21, 2018 at 12:59 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coffee_time`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `article_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_for_caffe` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`article_id`, `name`, `description`, `type`, `fk_for_caffe`, `created_at`, `updated_at`) VALUES
(1, 'vidza', 'dff', 'Voda', 3, '2018-06-20 20:50:34', '2018-06-20 20:50:34');

-- --------------------------------------------------------

--
-- Table structure for table `caffe`
--

CREATE TABLE `caffe` (
  `caffe_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `short_description` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `work_hour_from` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `work_hour_to` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `www` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `call_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `caffe`
--

INSERT INTO `caffe` (`caffe_id`, `name`, `address`, `city`, `description`, `created_at`, `updated_at`, `short_description`, `work_hour_from`, `work_hour_to`, `image`, `www`, `call_number`) VALUES
(3, 'ABC Safari', 'Adresa2', 'Leskovac', 'Najbolji kafic u Leskovac a i sire!', '2018-06-10 19:04:10', '2018-06-18 21:33:43', 'edew', '09:00', '21:00', '', 'www.somelink.com', '123123'),
(4, 'Transformers', 'some address', 'Nis', 'Mi smo taj opis', '2018-06-18 20:40:16', '2018-06-18 20:40:16', 'Neki Opis', '09:00', '23:00', '1529361615.jpg', 'www.somelink.com', '123123'),
(16, 'dsffsd', 'dsfdsf', 'sdfds', 'ffds', '2018-06-20 20:48:26', '2018-06-20 20:48:26', 'ewfewfefw', '09:00', '21:00', '1529534905.jpg', 'www.somelink.com', '12312');

-- --------------------------------------------------------

--
-- Table structure for table `financials`
--

CREATE TABLE `financials` (
  `financial_id` int(10) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `neto_value` int(11) NOT NULL,
  `bruto_value` int(11) NOT NULL,
  `pdv` int(11) NOT NULL,
  `fk_for_caffe` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `menu_id` int(10) UNSIGNED NOT NULL,
  `fk_for_caffe` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`menu_id`, `fk_for_caffe`, `name`, `created_at`, `updated_at`) VALUES
(1, 3, 'vidza', '2018-06-20 20:51:44', '2018-06-20 20:51:44');

-- --------------------------------------------------------

--
-- Table structure for table `menu_article`
--

CREATE TABLE `menu_article` (
  `neto_price` int(11) NOT NULL,
  `selling_price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `menu_id` int(10) UNSIGNED NOT NULL,
  `article_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menu_article`
--

INSERT INTO `menu_article` (`neto_price`, `selling_price`, `quantity`, `menu_id`, `article_id`, `created_at`, `updated_at`) VALUES
(22, 22, 3, 1, 1, '2018-06-20 20:52:08', '2018-06-20 20:52:08');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_05_05_074043_create_caffe_table', 1),
(3, '2018_05_05_074449_create_users_table', 1),
(4, '2018_05_05_080803_create_user_details_table', 1),
(11, '2018_06_10_103705_entrust_setup_tables', 1),
(27, '2018_05_05_074438_create_tables_table', 2),
(28, '2018_05_05_080900_create_articles_table', 2),
(29, '2018_05_05_080930_create_menu_table', 2),
(30, '2018_05_05_081002_create_menu_article_table', 2),
(31, '2018_05_05_081106_create_financials_table', 2),
(32, '2018_05_05_104154_create_orders_table', 2),
(33, '2018_05_05_104311_create_order_tables_user_table', 2),
(34, '2018_06_20_011543_create_notifications_table', 2),
(35, '2018_06_20_013153_create_reservations_table', 2),
(36, '2018_06_20_225614_create_posts_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` int(10) UNSIGNED NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(10) UNSIGNED NOT NULL,
  `neto_total` int(11) NOT NULL,
  `selling_total` int(11) NOT NULL,
  `is_charged` tinyint(1) NOT NULL DEFAULT '0',
  `fk_for_financial` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ord_tbl_usr`
--

CREATE TABLE `ord_tbl_usr` (
  `ord_tbl_id` int(10) UNSIGNED NOT NULL,
  `menu_id` int(10) UNSIGNED NOT NULL,
  `article_id` int(10) UNSIGNED NOT NULL,
  `table_id` int(10) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `order_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `employee_id` int(10) UNSIGNED DEFAULT NULL,
  `date` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'create', 'Create Record', 'Allow user to create a new DB record', '2018-06-10 15:55:46', '2018-06-10 15:55:46'),
(2, 'edit', 'Edit Record', 'Allow user to edit an existing DB record', '2018-06-10 15:55:46', '2018-06-10 15:55:46'),
(3, 'delete', 'Delete Record', 'Allow user to delete an existing DB record', '2018-06-10 15:55:46', '2018-06-10 15:55:46'),
(4, 'users', 'Manage Users', 'Allow user to manage system users', '2018-06-10 15:55:46', '2018-06-10 15:55:46'),
(5, 'article', 'Proizvodi', 'Manage articles', NULL, NULL),
(6, 'caffe', 'Kafic', 'Manage caffe', NULL, NULL),
(13, 'table', 'Stolovi', 'Manage tables', NULL, NULL),
(14, 'view', 'Pregledaj', 'View DB records', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`permission_id`, `role_id`) VALUES
(1, 1),
(1, 2),
(2, 1),
(2, 2),
(3, 1),
(3, 2),
(4, 1),
(4, 2),
(5, 1),
(5, 2),
(5, 3),
(6, 1),
(6, 2),
(6, 3),
(13, 1),
(13, 2),
(13, 3),
(14, 1),
(14, 2),
(14, 3);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fk_for_caffe` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `content`, `fk_for_caffe`, `created_at`, `updated_at`) VALUES
(1, 'Neki post', 'cdc', 3, '2018-06-20 20:59:08', '2018-06-20 20:59:08');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `reservation_id` int(10) UNSIGNED NOT NULL,
  `fk_for_table` int(10) UNSIGNED NOT NULL,
  `fk_for_caffe` int(10) UNSIGNED NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `priority`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Administrator', 'User has access to all system functionality', 1000, '2018-06-10 15:55:57', '2018-06-10 15:55:57'),
(2, 'owner', 'Vlasnik', 'User can create create and edit data in the system', 500, '2018-06-10 15:55:57', '2018-06-10 15:55:57'),
(3, 'employee', 'Radnik', 'User can read specific data in the system', 100, '2018-06-10 15:55:57', '2018-06-10 15:55:57'),
(4, 'user', 'Korisnik', 'User can read specific data in the system', 1, '2018-06-10 15:55:57', '2018-06-10 15:55:57');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`user_id`, `role_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tables`
--

CREATE TABLE `tables` (
  `table_id` int(10) UNSIGNED NOT NULL,
  `table_number` int(11) NOT NULL,
  `table_spots` int(11) NOT NULL,
  `is_taken` tinyint(1) NOT NULL DEFAULT '0',
  `is_reserved` tinyint(1) NOT NULL DEFAULT '0',
  `fk_for_caffe` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tables`
--

INSERT INTO `tables` (`table_id`, `table_number`, `table_spots`, `is_taken`, `is_reserved`, `fk_for_caffe`, `created_at`, `updated_at`) VALUES
(1, 2, 3, 0, 0, 3, '2018-06-20 20:49:28', '2018-06-20 20:49:28'),
(2, 2, 3, 0, 0, 4, '2018-06-20 20:49:51', '2018-06-20 20:49:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fk_for_caffe` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `remember_token`, `fk_for_caffe`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'vasd@as.com', '$2y$10$p8MdUVBbV8wbB1LKJIyq4.PLGiSJqxqImqdLqXiedD4zFa/4eBwjW', '5pTztXDYnIhCIrZdjrZhhf3oPFcBxKl1NsSkEyhs58KsL91E9ankbJuJ6q8i', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `detail_id` int(10) UNSIGNED NOT NULL,
  `pid` int(11) NOT NULL,
  `first_name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int(11) NOT NULL,
  `employee_number` int(11) DEFAULT NULL,
  `fk_for_user` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`detail_id`, `pid`, `first_name`, `last_name`, `address`, `phone_number`, `gender`, `age`, `employee_number`, `fk_for_user`, `created_at`, `updated_at`) VALUES
(1, 123123, 'Vidoje', 'Mijalkovic', 'Asd 123', '123123', 'M', 24, NULL, 1, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`article_id`),
  ADD KEY `articles_fk_for_caffe_foreign` (`fk_for_caffe`);

--
-- Indexes for table `caffe`
--
ALTER TABLE `caffe`
  ADD PRIMARY KEY (`caffe_id`);

--
-- Indexes for table `financials`
--
ALTER TABLE `financials`
  ADD PRIMARY KEY (`financial_id`),
  ADD KEY `financials_fk_for_caffe_foreign` (`fk_for_caffe`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`menu_id`),
  ADD KEY `menu_fk_for_caffe_foreign` (`fk_for_caffe`);

--
-- Indexes for table `menu_article`
--
ALTER TABLE `menu_article`
  ADD KEY `menu_article_menu_id_foreign` (`menu_id`),
  ADD KEY `menu_article_article_id_foreign` (`article_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_id_notifiable_type_index` (`notifiable_id`,`notifiable_type`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `orders_fk_for_financial_foreign` (`fk_for_financial`);

--
-- Indexes for table `ord_tbl_usr`
--
ALTER TABLE `ord_tbl_usr`
  ADD PRIMARY KEY (`ord_tbl_id`),
  ADD KEY `ord_tbl_usr_menu_id_foreign` (`menu_id`),
  ADD KEY `ord_tbl_usr_order_id_foreign` (`order_id`),
  ADD KEY `ord_tbl_usr_article_id_foreign` (`article_id`),
  ADD KEY `ord_tbl_usr_user_id_foreign` (`user_id`),
  ADD KEY `ord_tbl_usr_employee_id_foreign` (`employee_id`),
  ADD KEY `ord_tbl_usr_table_id_foreign` (`table_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `permission_role_role_id_foreign` (`role_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `posts_fk_for_caffe_foreign` (`fk_for_caffe`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`reservation_id`),
  ADD KEY `reservations_fk_for_table_foreign` (`fk_for_table`),
  ADD KEY `reservations_fk_for_caffe_foreign` (`fk_for_caffe`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Indexes for table `tables`
--
ALTER TABLE `tables`
  ADD PRIMARY KEY (`table_id`),
  ADD KEY `tables_fk_for_caffe_foreign` (`fk_for_caffe`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `users_fk_for_caffe_foreign` (`fk_for_caffe`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`detail_id`),
  ADD KEY `user_details_fk_for_user_foreign` (`fk_for_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `article_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `caffe`
--
ALTER TABLE `caffe`
  MODIFY `caffe_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `financials`
--
ALTER TABLE `financials`
  MODIFY `financial_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `menu_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ord_tbl_usr`
--
ALTER TABLE `ord_tbl_usr`
  MODIFY `ord_tbl_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `reservation_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tables`
--
ALTER TABLE `tables`
  MODIFY `table_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `detail_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `articles`
--
ALTER TABLE `articles`
  ADD CONSTRAINT `articles_fk_for_caffe_foreign` FOREIGN KEY (`fk_for_caffe`) REFERENCES `caffe` (`caffe_id`) ON DELETE CASCADE;

--
-- Constraints for table `financials`
--
ALTER TABLE `financials`
  ADD CONSTRAINT `financials_fk_for_caffe_foreign` FOREIGN KEY (`fk_for_caffe`) REFERENCES `caffe` (`caffe_id`) ON DELETE CASCADE;

--
-- Constraints for table `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `menu_fk_for_caffe_foreign` FOREIGN KEY (`fk_for_caffe`) REFERENCES `caffe` (`caffe_id`) ON DELETE CASCADE;

--
-- Constraints for table `menu_article`
--
ALTER TABLE `menu_article`
  ADD CONSTRAINT `menu_article_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`article_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `menu_article_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`menu_id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_fk_for_financial_foreign` FOREIGN KEY (`fk_for_financial`) REFERENCES `financials` (`financial_id`) ON DELETE CASCADE;

--
-- Constraints for table `ord_tbl_usr`
--
ALTER TABLE `ord_tbl_usr`
  ADD CONSTRAINT `ord_tbl_usr_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`article_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ord_tbl_usr_employee_id_foreign` FOREIGN KEY (`employee_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ord_tbl_usr_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`menu_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ord_tbl_usr_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ord_tbl_usr_table_id_foreign` FOREIGN KEY (`table_id`) REFERENCES `tables` (`table_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ord_tbl_usr_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_fk_for_caffe_foreign` FOREIGN KEY (`fk_for_caffe`) REFERENCES `caffe` (`caffe_id`) ON DELETE CASCADE;

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_fk_for_caffe_foreign` FOREIGN KEY (`fk_for_caffe`) REFERENCES `caffe` (`caffe_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reservations_fk_for_table_foreign` FOREIGN KEY (`fk_for_table`) REFERENCES `tables` (`table_id`) ON DELETE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tables`
--
ALTER TABLE `tables`
  ADD CONSTRAINT `tables_fk_for_caffe_foreign` FOREIGN KEY (`fk_for_caffe`) REFERENCES `caffe` (`caffe_id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_fk_for_caffe_foreign` FOREIGN KEY (`fk_for_caffe`) REFERENCES `caffe` (`caffe_id`) ON DELETE CASCADE;

--
-- Constraints for table `user_details`
--
ALTER TABLE `user_details`
  ADD CONSTRAINT `user_details_fk_for_user_foreign` FOREIGN KEY (`fk_for_user`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
